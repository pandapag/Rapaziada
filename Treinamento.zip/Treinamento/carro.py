class Carro:
    def __init__(self, lataria, marca, preca, placa):
        self.lataria = lataria
        self.marca = marca
        self.preca = preca
        self.placa = placa

