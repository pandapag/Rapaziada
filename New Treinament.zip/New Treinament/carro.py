from compra import *

class Carro:
    def __init__(self, preco):
        self.preco = preco

